cmp ecx, ecx
jne cond
add edx, ecx
jmp done
cond:
mov eax, done
inc ebx
done:
ret