#include <stdint.h>
#include <stdio.h>
#include <string.h>

static int check_login(const unsigned char *buf) {
  if (strlen((const char *)buf) != 18)
    return 0;

  if (buf[0] != 'i' || buf[1] != 'c' || buf[2] != 's' || buf[3] != 't')
    return 0;
  if (buf[4] != '-')
    return 0;

  if ((buf[5] ^ 0x13) != ('b' ^ 0x13))
    return 0;
  if ((uint8_t)(buf[6] + 7) != (uint8_t)('2' + 7))
    return 0;
  if ((buf[7] - 3) != ('r' - 3))
    return 0;
  if ((buf[8] ^ buf[5]) != ('2' ^ 'b'))
    return 0;
  if (buf[9] != '-')
    return 0;
  if ((buf[10] ^ 0x21) != ('t' ^ 0x21))
    return 0;
  if ((uint8_t)(buf[11] + 4) != (uint8_t)('u' + 4))
    return 0;
  if (buf[12] != 't' || buf[13] != 'o' || buf[14] != 'r')
    return 0;
  if ((buf[15] - 2) != ('i' - 2))
    return 0;
  if ((buf[16] ^ buf[10]) != ('a' ^ 't'))
    return 0;

  return buf[17] == 'l' && buf[18] == '\0';
}

int main(int argc, char **argv) {
  if (argc != 2) {
    puts("usage: loginme <word>");
    return 1;
  }

  if (check_login((const unsigned char *)argv[1])) {
    puts("Access granted");
    return 0;
  } else {
    puts("Access denied");
    return 1;
  }
}
