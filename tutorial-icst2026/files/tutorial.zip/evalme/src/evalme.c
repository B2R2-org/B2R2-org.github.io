#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#if defined(__linux__)
#include <errno.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#endif

#if defined(__GNUC__)
#define NOINLINE __attribute__((noinline))
#else
#define NOINLINE
#endif

static uint8_t rol8(uint8_t x, unsigned int n) {
  return (uint8_t)((x << n) | (x >> (8U - n)));
}

static uint8_t ror8(uint8_t x, unsigned int n) {
  return (uint8_t)((x >> n) | (x << (8U - n)));
}

static uint8_t key_byte(uint32_t i) {
  uint32_t x = 0xa5b35705U ^ (i * 0x45d9f3bU);
  x ^= x >> 13;
  x *= 0x85ebca6bU;
  x ^= x >> 16;
  return (uint8_t)((x >> ((i & 3U) * 8U)) ^ (0x31U + i * 17U));
}

static NOINLINE uint32_t round_state(uint32_t state, uint8_t v,
                                     uint8_t out, uint32_t i) {
  state ^= (uint32_t)v + ((uint32_t)out << 8) + i * 0x10203U;
  state = (state << 7) | (state >> 25);
  state += 0x9e3779b9U ^ (i * 0x45d9f3bU);
  state ^= state >> 15;
  return state;
}

static NOINLINE uint8_t table_mask(uint32_t state, uint32_t i) {
  uint8_t a = (uint8_t)((state >> ((i & 3U) * 8U)) & 0xffU);
  uint8_t b = (uint8_t)((state >> (((i + 1U) & 3U) * 8U)) & 0xffU);
  return rol8((uint8_t)(a ^ b ^ key_byte(i)), (i & 3U) + 1U);
}

static NOINLINE uint8_t decode_byte(uint8_t v, uint32_t state,
                                    uint8_t carry, uint32_t i) {
  uint8_t x = (uint8_t)(v ^ key_byte(i));
  x = rol8(x, (i % 5U) + 1U);
  x = (uint8_t)(x + table_mask(state, i));
  x ^= (uint8_t)((state >> ((i & 3U) * 8U)) & 0xffU);
  x = ror8(x, (i % 3U) + 1U);
  x = (uint8_t)(x - (uint8_t)((i * 29U) ^ 0x4dU));
  x ^= carry;
  x ^= (uint8_t)(0xa7U + i * 13U);
  return x;
}

static NOINLINE uint8_t next_carry(uint8_t carry, uint8_t out,
                                   uint8_t v, uint32_t state, uint32_t i) {
  return (uint8_t)(rol8((uint8_t)(carry + out + v), 1) ^ table_mask(state, i));
}

static NOINLINE void decode(char out[32]) {
  static const uint8_t encoded[14] = {
    0xc4, 0x08, 0xbd, 0xed, 0xae, 0x39, 0x2e,
    0xf9, 0xcc, 0xdb, 0xb6, 0xd6, 0x00, 0x29,
  };

  uint32_t checksum = 0x6d2b79f5U;
  uint32_t guard = 0x13572468U;
  uint8_t carry = 0x42U;

  for (uint32_t i = 0; i < 14U; i++) {
    uint8_t v = encoded[i];
    uint8_t plain = decode_byte(v, checksum, carry, i);

    guard += (uint32_t)(v ^ plain) * (i + 3U);
    guard = (guard << 5) | (guard >> 27);
    checksum = round_state(checksum, v, plain, i);
    carry = next_carry(carry, plain, v, checksum, i);
    out[i] = (char)plain;
  }

  if (guard != 0xf96fceb9U)
    out[0] = '\0';
  out[14] = '\0';
}

static void anti_debug(void) {
#if defined(__linux__)
  errno = 0;
  if (ptrace(PTRACE_TRACEME, 0, 0, 0) == -1 && errno != 0) {
    puts("debugger detected");
    exit(2);
  }
#endif
}

int main(int argc, char **argv) {
  char expected[32] = { 0 };

  if (argc != 2) {
    puts("usage: evalme <word>");
    return 1;
  }

  anti_debug();

  decode(expected);

  if (strcmp(argv[1], expected) == 0) {
    puts("accepted");
    return 0;
  }

  puts("rejected");
  return 1;
}
