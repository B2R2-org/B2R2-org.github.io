#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#if defined(__GNUC__)
#define NOINLINE __attribute__((noinline, noclone, used))
#else
#define NOINLINE
#endif

static NOINLINE void dummy0(void) {
  puts("Daisy, Daisy, give me your answer do! I'm half crazy, all for the love of you...");
  exit(0);
}

static NOINLINE void dummy1(void) {
  srand((unsigned int)time(NULL));
  volatile unsigned int honesty = (unsigned int)(rand() % 101);
  if (honesty >= 90)
    puts("Ninety per cent.");
  else
    puts("Ninety per cent.");
}

static NOINLINE void dummy2(void) {
  volatile uint64_t thought = 0;
  uint32_t year = 1250000U;
  for (; year <= 7500000U; year += 1250000U) {
    uint32_t epoch = year / 1250000U;
    thought += epoch * 2U;
  }
  printf("%llu\n", (unsigned long long)thought);
}

static NOINLINE void dummy4(void);

static NOINLINE void dummy3(void) {
  dummy4();
}

static NOINLINE void target(void) {
  puts("You find me!");
}

static NOINLINE void dummy4(void) {
  const char *things[3] = { "bird", "potato", "neurotoxin" };
  volatile unsigned int panic = 0;
  for (unsigned int i = 0; i < 3; i++) {
    panic += things[i][0] + i;
  }
  puts("Bird! Bird! Kill it! It's evil");
}

static NOINLINE void dummy5(void) {
  volatile uint32_t layers = 0;
  for (unsigned int i = 1; i <= 4; i++) {
    layers += i * i;
  }
  puts("There will be cake.");
  puts("                 (");
  puts("                (o)");
  puts("                ,|,");
  puts("                |~\\");
  puts("                \\ |");
  puts("                |`\\");
  puts("              @@\\ |@@");
  puts("            @@@@|`\\@@@@");
  puts("          o@@@@@\\ |@@@@@o");
  puts("        o@@@@@@@@@@@@@@@@@@o");
  puts("       @@@@@@@@@@@@@@@@@@@@@@");
  puts("       p@@@@@@@@@@@@@@@@@@@@q");
  puts("       @@o@@@@@@@@@@@@@@@@o@@");
  puts("       @:@@@o@@@@@@@@@@o@@::@");
  puts("       ::@@::@@o@@@@o@@:@@::@");
  puts("       ::@@::@@@@::@@@@:@@::::");
  puts("       %::::::@::::::@:::::::%");
  puts("       %%:::::::::::::::::::%%");
  puts("       ::%%%:::::::::::::%%%::");
  puts("     .#::%::%%%%%%%%%%%%%::%::#.");
  puts("   .###::::::%%:::::::%%::::::###.");
  puts(" .#####::::::%:::::::::%::::::#####.");
  puts(".######`::::::::::::::::::::'######.");
  puts(".#########``::::::::::::''#########.");
  puts("`.#############```::'''#############.'");
  puts("  `.##############################.'");
  puts("    ` .########################. '");
}

static NOINLINE void dummy6(void) {
  volatile uint32_t guard = 0;
  puts("This. Sentence. Is. FALSE don't think about it don't think about it...");
  goto escape;

if_else:
  if ((guard & 1U) != 0U)
    goto false_branch;
  else
    goto if_branch;

if_branch:
  goto false_branch;

false_branch:
  goto if_branch;

escape:
  if (guard == 0x31415926U)
    goto if_else;
}

static uint64_t hash_addr(uintptr_t addr) {
  uint64_t x = (uint64_t)addr ^ 0x9e3779b97f4a7c15ULL;
  x ^= x >> 30;
  x *= 0xbf58476d1ce4e5b9ULL;
  x ^= x >> 27;
  x *= 0x94d049bb133111ebULL;
  x ^= x >> 31;
  return x;
}

static const uint64_t allowed_hashes[] = {
  0x8102b7b43cc4e9e5ULL,
  0xf974343236f1c9f9ULL,
  0x7b4f03832515c891ULL,
  0xa5d1de32b49ee3caULL,
  0xe910e1b231ec5cf8ULL,
  0xd6000466902d1112ULL,
  0x1efc4e59848deef7ULL,
  0x99a8ab86b4e29731ULL,
};

static int is_allowed_entry(uintptr_t addr) {
  uint64_t h = hash_addr(addr);
  for (size_t i = 0; i < sizeof(allowed_hashes) / sizeof(allowed_hashes[0]); i++) {
    if (allowed_hashes[i] == h)
      return 1;
  }
  return 0;
}

static void dispatch(uintptr_t addr) {
  if (!is_allowed_entry(addr)) {
    puts("You are not allowed.");
    return;
  }
  void (*fn)(void) = (void (*)(void))addr;
  fn();
}

int main(int argc, char **argv) {
  if (argc == 2) {
    uintptr_t addr = (uintptr_t)strtoull(argv[1], NULL, 16);
    dispatch(addr);
    return 0;
  }

  puts("Enter addresses (without 0x) until you find the target or HAL terminates the session.");

  char buf[64];
  while (fgets(buf, sizeof(buf), stdin) != NULL) {
    uintptr_t addr = (uintptr_t)strtoull(buf, NULL, 16);
    dispatch(addr);
  }
  return 0;
}
